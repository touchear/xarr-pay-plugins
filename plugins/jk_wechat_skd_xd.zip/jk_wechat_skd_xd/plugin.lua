-- 载入插件
local currentPath = debug.getinfo(1, "S").source:sub(2)
local projectDir = currentPath:match("(.*/)")
package.path = package.path .. ";." .. projectDir .. "../../common/?.lua"

local funcs = require("funcs")
local http = require("http")
local json = require("json")
local log = require("log")
local helper = require("helper")
local orderPayHelper = require("orderPayHelper")

-- 定义常量
PAY_WXPAY_SKD_XD = "jk_wechat_skd_xd"

-- 定义网关常量
local GATEWAY = {
    BASE = "https://payapp.wechatpay.cn",
    RECEIPT_MD = "https://payapp.wechatpay.cn/receiptmdmgr",
    RECEIPT_SJT = "https://payapp.wechatpay.cn/receiptsjtmgr",
    RECEIPT_WX = "https://payapp.wechatpay.cn/receiptwxmgr"
}

--- 插件信息
plugin = {
    info = {
        name = PAY_WXPAY_SKD_XD,
        title = '微信收款单-XD监控端',
        author = '',
        description = "监控插件",
        link = '',
        version = "1.4.6.5",
        -- 支持支付类型
        channels = {
            wxpay = {{
                label = '微信收款单-XD监控端',
                value = PAY_WXPAY_SKD_XD,
                -- 支持上报
                report = 1,
                options = {
                    need_check_online = 1,
                    bind_client_name = 1
                }
            }}
        },
        options = {
            detection_interval = 5,
            detection_type = "cron" --- order 单订单检查 cron 定时执行任务
        }

    }
}

function plugin.pluginInfo()
    return json.encode(plugin.info)
end

-- 获取form表单
function plugin.formItems(payType, payChannel)
    return json.encode({
        inputs = {{
            name = 'sid',
            label = 'SID',
            type = 'input',
            default = "",
            options = {
                tip = ''
            },
            placeholder = "请输入Sid或等待上报"
        }, {
            name = 'account_list',
            label = '账号列表(一行一组)',
            type = 'textarea',
            default = "",
            when = "this.formModel.options.sid",
            hidden_list = 1,
            placeholder = "清空后会重新获取",
            options = {
                tip = '清空后会点保存会重新获取,如需切换账号ID,可在此处复制到下面对应输入框替换',
                autosize = {
                    minRows = 1,
                    maxRows = 10
                }
            }
        }, {
            name = 'aid',
            label = '账号ID',
            type = 'input',
            when = "this.formModel.options.sid",
            default = "",
            placeholder = "请输入账号ID",
            options = {
                tip = "请从账号列表选一组账号信息的账号ID填入此处"
            }
        }, {
            name = 'account_type',
            label = '账号类型',
            type = 'input',
            when = "this.formModel.options.sid",
            default = "",
            placeholder = "请输入账号类型[1-3],不行就换下一个",
            options = {
                tip = "请从账号列表选一组账号信息的账号类型填入此处"
            }

        }, {
            name = 'shop_id',
            label = '店铺ID',
            type = 'input',
            default = "",
            when = "this.formModel.options.sid",
            options = {
                tip = '店铺ID保存/定时刷新'
            },
            placeholder = "请输入商户ID"
        }, {
            name = 'report_type',
            label = '上报方式',
            type = 'radio',
            default = "server",
            options = {
                tip = '客户端: 需要客户端监控上报, 服务器: 服务端主动监控上报 (此处客户端上报依然会有效)'
            },
            placeholder = "请选择上报方式",
            values = {{
                label = "客户端上报",
                value = "client"
            }, {
                label = "服务器上报",
                value = "server"
            }},
            rules = {{
                required = true,
                trigger = {"input", "blur"},
                message = "请输入"
            }}
        }, {
            name = 'scan_type',
            label = '订单检查方式',
            type = 'radio',
            default = "order_or_amount",
            options = {
                tip = ''
            },
            placeholder = "请选择订单检查方式",
            values = {{
                label = "订单号匹配不到则使用金额",
                value = "order_or_amount"
            }, {
                label = "订单号",
                value = "order"
            }},
            rules = {{
                required = true,
                trigger = {"input", "blur"},
                message = "请输入"
            }}
        }, {
            name = 'order_temp_amount',
            label = '取消订单递增金额',
            type = 'radio',
            default = "0",
            options = {
                tip = '<b>注意:</b>订单检查方式为订单号的时候才能选择[是]'
            },
            placeholder = "请选择订单检查方式",
            values = {{
                label = "否",
                value = "0"
            }, {
                label = "是",
                value = "1"
            }},
            rules = {{
                required = true,
                trigger = {"input", "blur"},
                message = "请输入"
            }}
        }}
    })
end

-- 统一的错误响应处理
plugin._error_response = function(err_code, err_message)
    return json.encode({
        err_code = err_code,
        err_message = err_message
    })
end

-- 统一的HTTP响应检查
plugin._check_http_response = function(resp, account_id, operation)
    if resp == nil then
        log.warning(string.format("[%s] (%s) %s请求失败", plugin.info.name, account_id, operation))
        return false
    end

    if resp.status_code ~= 200 then
        log.warning(string.format("[%s] (%s) %s失败,状态码:%d", plugin.info.name, account_id, operation,
            resp.status_code))
        return false
    end

    if resp.body == "" then
        log.warning(string.format("[%s] (%s) %s失败,返回数据为空", plugin.info.name, account_id, operation))
        return false
    end

    local data = json.decode(resp.body)
    if not data or data.errcode ~= 0 then
        log.warning(string.format("[%s] (%s) %s失败,错误码:%d", plugin.info.name, account_id, operation,
            data and data.errcode or -1))
        return false
    end

    return true, data
end

-- 参数验证
plugin._validate_params = function(params, required_fields)
    for _, field in ipairs(required_fields) do
        if not params[field] or params[field] == "" then
            return false, string.format("缺少必要参数: %s", field)
        end
    end
    return true
end

-- 账号类型判断
plugin._get_gateway_by_account_type = function(account_type)
    account_type = tonumber(account_type) or account_type
    if account_type == 1 or account_type == "1" then
        return GATEWAY.RECEIPT_MD
    elseif account_type == 3 or account_type == "3" then
        return GATEWAY.RECEIPT_SJT
    end
    return nil
end

-- 创建订单
function plugin.create(pOrderInfo, pPluginOptions, pAccountInfo, pDeviceInfo)
    local orderInfo = json.decode(pOrderInfo)
    local options = json.decode(pPluginOptions)
    local vAccountInfo = json.decode(pAccountInfo)

    -- 验证必要参数
    local valid, err_message = plugin._validate_params(options, {"sid", "shop_id", "aid"})
    if not valid then
        return plugin._error_response(500, err_message)
    end

    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(options.account_type)
    if not gateway then
        return plugin._error_response(500, "不支持的账号类型")
    end

    -- 构建请求URL和参数
    local url = gateway .. "/receipt/create"
    url = url .. "?account_type=" .. options.account_type
    url = url .. "&account_id=" .. options.aid
    url = url .. "&sid=" .. options.sid

    log.info(string.format("(%s) %s(%s) 创建订单,url:%s", plugin.info.name, vAccountInfo.name, vAccountInfo.id, url))

    local body = {
        miniprogram_version = "3.15.10",
        fee = orderInfo.trade_amount,
        remark = orderInfo.order_id,
        remark_pic_urls = "",
        option_list = {},
        receipt_item_list = {},
        shop_id = tonumber(options.shop_id),
        sid = options.sid
    }

    local result = http.post(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        },
        body = json.encode(body)
    })

    log.debug(string.format("[插件] (%s) 创建订单 GET %s", plugin.info.name, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = string.format("请求失败,状态码:%d", result.status_code)
        })
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return json.encode({
            err_code = 500,
            err_message = "解析返回数据失败"
        })
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return json.encode({
            err_code = 500,
            err_message = response.msg or "创建订单失败"
        })
    end

    -- 提取receipt_id
    local receipt_id
    if response.data then
        if response.data.receipt then
            receipt_id = response.data.receipt.receipt_id
        end
    end
    if not receipt_id then
        return json.encode({
            err_code = 500,
            err_message = "未获取到receipt_id"
        })
    end

    -- 构建获取二维码URL
    url = gateway .. "/receipt/getwxacode"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&wxacode_path_type=1"
    url = url .. "&receipt_id=" .. receipt_id
    url = url .. "&account_id=" .. options.aid
    url = url .. "&account_type=" .. options.account_type
    url = url .. "&sid=" .. options.sid

    log.debug(string.format("[插件] (%s) 获取二维码 URL: %s", plugin.info.name, url))

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    -- log.debug(string.format("[插件] (%s) 获取二维码 GET %s", plugin.info.name, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = string.format("请求失败,状态码:%d", result.status_code)
        })
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return json.encode({
            err_code = 500,
            err_message = "解析返回数据失败"
        })
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return json.encode({
            err_code = 500,
            err_message = response.msg or "获取二维码失败"
        })
    end

    -- 提取二维码
    if not response.data then
        return json.encode({
            err_code = 500,
            err_message = "返回数据格式错误,缺少data字段"
        })
    end

    local qrcode = response.data.qrcode
    if not qrcode then
        return json.encode({
            err_code = 500,
            err_message = "未获取到二维码"
        })
    end

    if qrcode == "" then
        return json.encode({
            err_code = 500,
            err_message = "二维码内容为空"
        })
    end

    -- 将base64转为图片文件
    local write, filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return json.encode({
            err_code = 500,
            err_message = "二维码保存失败"
        })
    end

    log.info(string.format("(%s) %s(%s) 创建订单[%s] 二维码保存成功", plugin.info.name, vAccountInfo.name,
        vAccountInfo.id, orderInfo.order_id))
    return json.encode({
        type = "qrcode",
        qrcode_file = filePath,
        url = "",
        content = "",
        out_trade_no = tostring(receipt_id),
        err_code = 200,
        err_message = ""
    })

end

-- 支付回调
function plugin.notify(request, orderInfo, params, pluginOptions)
    -- 判断请求方式
    return json.encode({
        error_code = 500,
        error_message = "暂不支持",
        response = ""
    })

end

-- 获取账号列表
function plugin.getAccountList(sid)
    local url = GATEWAY.RECEIPT_WX .. "/account/list"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&sid=" .. sid

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    -- 判断返回状态
    if result.status_code ~= 200 then
        return nil, string.format("请求账号列表失败,状态码:%d", result.status_code)
    end

    print(result.body)

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return nil, "解析账号列表数据失败"
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return nil, response.msg or "获取账号列表失败"
    end

    -- 返回账号列表数据
    if response.data and response.data.account_list then
        return response.data.account_list, nil
    end

    return nil, "账号列表为空"
end

-- 客户端心跳上报处理
function plugin.heartbeat(pChannelAccount, pHeartbeatRequest)
    local channelAccount = json.decode(pChannelAccount)
    local options = json.decode(channelAccount.options)

    -- 打印心跳数据
    log.info(string.format("(%s) 心跳数据: %s", channelAccount.plugin_name, pHeartbeatRequest))

    -- 解析心跳数据
    local heartbeatData = json.decode(pHeartbeatRequest)
    if heartbeatData == nil or heartbeatData.ext_data == nil or heartbeatData.ext_data == "" then
        return json.encode({
            err_code = 500,
            err_message = "心跳数据解析失败"
        })
    end

    -- 解析扩展数据
    local extData = json.decode(heartbeatData.ext_data)
    log.info(string.format("(%s) 心跳扩展数据 sid:%s", channelAccount.plugin_name, extData.sid))

    -- 保存配置
    helper.channel_account_set_option(channelAccount.id, "sid", extData.sid)

    -- 如果离线状态 则设置为在线
    if channelAccount.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(channelAccount.id)
    end

    return json.encode({
        err_code = 200,
        err_message = "心跳正常"
    })
end

-- 验证账号并初始化
plugin._verify_and_init_account = function(accountInfo, options)
    -- 判断是否有SID 
    if options.sid == "" then
        return false, "暂未填写sid"
    end

    -- 判断是否需要获取账号列表
    if options.account_list == "" then
        -- 获取账号列表
        local accountList, err = plugin.getAccountList(options.sid)
        if err then
            return false, err
        end

        -- 保存账号列表
        if accountList then
            local lines = {}
            local activatedAccounts = {}
            for _, account in ipairs(accountList) do
                if account.account_status == "ACTIVATED" then
                    local line = string.format("账号ID:%s|账号类型:%s|商户名称:%s", account.account_id or "",
                        account.account_type or "", account.account_name or "")
                    table.insert(lines, line)
                    table.insert(activatedAccounts, account)
                end
            end
            local accountListStr = table.concat(lines, "\n")
            helper.channel_account_set_option(accountInfo.id, "account_list", accountListStr)

            -- 如果只有一个账号，则自动选择第一个账号
            if #activatedAccounts > 0 then
                helper.channel_account_set_option(accountInfo.id, "aid", activatedAccounts[1].account_id)
                helper.channel_account_set_option(accountInfo.id, "account_type", activatedAccounts[1].account_type)
                options.aid = activatedAccounts[1].account_id
                options.account_type = tostring(activatedAccounts[1].account_type)

                log.info(string.format("(%s) 账号列表获取成功 自动选择账号ID:%s,账号类型:%s",
                    accountInfo.id, options.aid, options.account_type))
            end
        end
    end

    -- 判断用户是否选择了aid
    if options.aid == "" then
        return false, "请选择一个账号"
    end

    -- 判断account_type
    if options.account_type == "" then
        return false, "请选择一个账号类型"
    end

    local shop_id = plugin._get_shop_id(options.sid, options.aid, options.account_type)
    if shop_id then
        helper.channel_account_set_option(accountInfo.id, "shop_id", shop_id)
        options.shop_id = shop_id
    else
        return false, "获取商户ID失败"
    end

    return true, ""
end

-- 通道新增或修改
function plugin.accountChanged(pAccountInfo)
    local accountInfo = json.decode(pAccountInfo)
    local options = json.decode(accountInfo.options)

    local success, err_message = plugin._verify_and_init_account(accountInfo, options)
    if not success then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return json.encode({
            err_code = 500,
            err_message = err_message
        })
    end

    -- 如果离线状态 则设置为在线
    if accountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(accountInfo.id)
    end

    return json.encode({
        err_code = 200,
        err_message = "账号验证成功"
    })
end

-- 定时任务
function plugin.cron(pAccountInfo, pPluginOptions)
    local accountInfo = json.decode(pAccountInfo)
    local options = json.decode(pPluginOptions)

    local success, err_message = plugin._verify_and_init_account(accountInfo, options)
    if not success then
        if accountInfo.online == 1 then
            helper.channel_account_offline(accountInfo.id)
        end
        return json.encode({
            err_code = 500,
            err_message = err_message
        })
    end

    -- 如果离线状态 则设置为在线
    if accountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(accountInfo.id)
    end

    -- 获取订单列表
    local orderList = plugin._get_order_list(options.account_type, options.aid, options.sid)
    if orderList == nil then
        -- 设置离线
        helper.channel_account_offline(accountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = "获取订单列表失败"
        })
    end

    if not orderList or #orderList == 0 then
        return json.encode({
            err_code = 200,
            err_message = "暂无订单"
        })
    end

    -- 遍历订单列表处理
    for _, order in ipairs(orderList) do
        plugin._handle_order(order, options, accountInfo)
    end

    return json.encode({
        err_code = 200,
        err_message = "处理完成"
    })
end

-- 处理单个订单
plugin._handle_order = function(order, options, accountInfo)
    if order.state == "close" then
        plugin._handle_closed_order(order, options)
    elseif order.state == "receiving" then
        plugin._handle_receiving_order(order, options)
    elseif order.state == "success" then
        plugin._handle_success_order(order, options, accountInfo)
    end
end

-- 处理已关闭订单
plugin._handle_closed_order = function(order, options)
    local create_time = tonumber(order.create_time)
    local now = os.time()
    -- 超过一天则删除
    if now - create_time > 86400 then -- 一天 = 86400秒
        plugin._delete_receipt(options.account_type, options.aid, options.sid, order.receipt_id)
    end
end

-- 处理接收中订单
plugin._handle_receiving_order = function(order, options)
    local create_time = tonumber(order.create_time)
    local now = os.time()
    -- 超过10分钟则关闭
    if now - create_time > 600 then -- 10分钟 = 600秒
        plugin._close_order(options.account_type, options.aid, options.sid, order.receipt_id)
    end
end

-- 处理成功订单
plugin._handle_success_order = function(order, options, accountInfo)
    -- 如果不是客户端上报方式,则录入订单
    if options.report_type ~= "client" then
        -- 提取外部订单号
        local out_order_id = plugin._extract_order_id(order.remark)
        -- 如果订单不存在则录入
        if not plugin._is_order_exists(order, options, accountInfo) then
            plugin._insert_and_report_order(order, out_order_id, options, accountInfo)
        end
    end

    -- 关闭订单
    plugin._close_order(options.account_type, options.aid, options.sid, order.receipt_id)
end

-- 从备注中提取订单号
plugin._extract_order_id = function(remark)
    local out_order_id = ""
    if remark then
        remark = string.gsub(remark, "请勿添加备注-", "")
        local matched, matchGroups = helper.regexp_match_group(remark, "^(?<order_id>\\d{20})$")
        if matched then
            matchGroups = json.decode(matchGroups)
            if matchGroups["order_id"] then
                out_order_id = matchGroups["order_id"][1]
                log.info(string.format("正则匹配订单号: %s", out_order_id))
            end
        end
    end
    return out_order_id
end

-- 检查订单是否存在
plugin._is_order_exists = function(order, options, accountInfo)
    return orderPayHelper.third_order_exist({
        pay_type = "wxpay",
        channel_code = PAY_WXPAY_SKD_XD,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        third_account = options.aid,
        third_order_id = order.receipt_id
    })
end

-- 插入并上报订单
plugin._insert_and_report_order = function(order, out_order_id, options, accountInfo)
    -- 录入数据
    local insertId = orderPayHelper.third_order_insert({
        pay_type = "wxpay",
        channel_code = PAY_WXPAY_SKD_XD,
        uid = accountInfo.uid,
        account_id = accountInfo.id,
        buyer_id = "",
        buyer_name = "",
        third_order_id = order.receipt_id,
        third_account = options.aid,
        amount = order.fee or 0,
        remark = order.remark,
        trans_time = tonumber(order.create_time),
        type = "收款单收款",
        out_order_id = out_order_id
    })

    -- 录入成功则上报
    if insertId > 0 then
        local err_code, err_message = orderPayHelper.third_order_report(insertId)
        if err_code == 200 then
            log.info(string.format("订单上报成功: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
                err_message, order.receipt_id, out_order_id, order.fee))
        else
            log.warning(string.format("订单上报失败: %s, 订单号: %s, 外部订单号: %s, 金额: %s",
                err_message, order.receipt_id, out_order_id, order.fee))
        end
    else
        log.warning(string.format("订单录入失败, 订单号: %s, 外部订单号: %s, 金额: %s",
            order.receipt_id, out_order_id, order.fee))
    end
end

-- 获取商户ID
plugin._get_shop_id = function(sid, account_id, account_type)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        return nil
    end

    local url = string.format(
        gateway .. "/account/get?miniprogram_version=3.15.10&account_id=%s&account_type=%s&sid=%s", account_id,
        account_type, sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local resp = http.get(url, {
        headers = headers
    })

    local success, data = plugin._check_http_response(resp, account_id, "获取商户ID")
    if not success then
        return nil
    end

    if data.data and data.data.auth_shop_list and #data.data.auth_shop_list > 0 then
        return data.data.auth_shop_list[1].shop_id
    end

    return nil
end

-- 获取订单列表
plugin._get_order_list = function(account_type, account_id, sid)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 获取订单列表 不支持的账号类型:%s", plugin.info.name,
            account_id, account_type))
        return nil
    end

    local url = string.format(gateway .. "/receipt/list?account_type=%s&account_id=%s&sid=%s", account_type, account_id,
        sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local body = {
        miniprogram_version = "3.15.10",
        start_time = 0,
        end_time = 0,
        page_size = 10,
        state = {},
        shop_id_list = {},
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success, data = plugin._check_http_response(resp, account_id, "获取订单列表")
    if not success then
        return nil
    end

    if data.data and data.data.receipt then
        -- 过滤掉 fee > 0 的数据
        local filtered = {}
        for _, receipt in ipairs(data.data.receipt) do
            if not receipt.fee or receipt.fee > 0 then
                table.insert(filtered, receipt)
            end
        end
        return filtered
    end

    return nil
end

-- 关闭订单
plugin._close_order = function(account_type, account_id, sid, receipt_id)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 关闭订单 不支持的账号类型:%s", plugin.info.name, account_id,
            account_type))
        return false
    end

    local url = string.format(gateway .. "/receipt/close?account_type=%s&account_id=%s&sid=%s", account_type,
        account_id, sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Mac MacWechat/WMPF MacWechat/3.8.7(0x13080712) UnifiedPCMacWechat(0xf2640006) XWEB/11500",
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html"
    }

    local body = {
        miniprogram_version = "3.15.10",
        receipt_id = receipt_id,
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success = plugin._check_http_response(resp, account_id, "关闭订单")
    return success
end

-- 删除订单
plugin._delete_receipt = function(account_type, account_id, sid, receipt_id)
    -- 获取网关
    local gateway = plugin._get_gateway_by_account_type(account_type)
    if not gateway then
        log.warning(string.format("[%s] (%s) 删除订单 不支持的账号类型:%s", plugin.info.name, account_id,
            account_type))
        return false
    end

    local url = string.format(gateway .. "/receipt/del?account_type=%s&account_id=%s&sid=%s", account_type, account_id,
        sid)

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Mac MacWechat/WMPF MacWechat/3.8.7(0x13080712) UnifiedPCMacWechat(0xf2640006) XWEB/11500",
        ["Content-Type"] = "application/json",
        ["Accept"] = "*/*",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html"
    }

    local body = {
        miniprogram_version = "3.15.10",
        receipt_id = receipt_id,
        sid = sid
    }

    local resp = http.post(url, {
        headers = headers,
        body = json.encode(body)
    })

    local success = plugin._check_http_response(resp, account_id, "删除订单")
    return success
end

-- 统一处理订单关闭和删除
plugin._handle_order_close_and_delete = function(account_type, account_id, sid, receipt_id)
    -- 先关闭订单
    if plugin._close_order(account_type, account_id, sid, receipt_id) then
        -- 关闭成功后删除
        plugin._delete_receipt(account_type, account_id, sid, receipt_id)
        return true
    end
    return false
end
