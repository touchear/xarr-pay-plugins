-- 载入插件
local currentPath = debug.getinfo(1, "S").source:sub(2)
local projectDir = currentPath:match("(.*/)")
package.path = package.path .. ";." .. projectDir .. "../../common/?.lua"

local funcs = require("funcs")
local http = require("http")
local json = require("json")
local log = require("log")
local helper = require("helper")

-- 定义常量
PAY_WXPAY_SKD_XD = "jk_wechat_skd_xd"

--- 插件信息
plugin = {
    info = {
        name = PAY_WXPAY_SKD_XD,
        title = '微信收款单-XD监控端',
        author = '',
        description = "监控插件",
        link = '',
        version = "1.4.6.5",
        -- 支持支付类型
        channels = {
            wxpay = {{
                label = '微信收款单-XD监控端',
                value = PAY_WXPAY_SKD_XD,
                -- 支持上报
                report = 1,
                options = {
                    need_check_online = 1,
                    bind_client_name = 1
                }
            }}
        },
        options = {
            detection_interval = 3,
            detection_type = "cron" --- order 单订单检查 cron 定时执行任务
        }

    }
}

function plugin.pluginInfo()
    return json.encode(plugin.info)
end

-- 获取form表单
function plugin.formItems(payType, payChannel)
    return json.encode({
        inputs = {{
            name = 'sid',
            label = 'SID',
            type = 'input',
            default = "",
            options = {
                tip = ''
            },
            placeholder = "请输入Sid或等待上报"
        }, {
            name = 'account_list',
            label = '账号列表(一行一组)',
            type = 'textarea',
            default = "",
            when = "this.formModel.options.sid",
            hidden_list = 1,
            placeholder = "清空后会重新获取",
            options = {
                tip = '',
                autosize = {
                    minRows = 1,
                    maxRows = 10
                }
            }
        }, {
            name = 'aid',
            label = '账号ID',
            type = 'input',
            when = "this.formModel.options.sid",
            default = "",
            placeholder = "请输入账号ID"
        }, {
            name = 'account_type',
            label = '账号类型',
            type = 'input',
            when = "this.formModel.options.sid",
            default = "",
            placeholder = "请输入账号类型[1-3],不行就换下一个"

        }, {
            name = 'shop_id',
            label = '商户ID',
            type = 'input',
            default = "",
            when = "this.formModel.options.sid",
            options = {
                tip = ''
            },
            placeholder = "请输入商户ID"

        }}
    })
end

-- 创建订单
function plugin.create(pOrderInfo, pPluginOptions, pAccountInfo, pDeviceInfo)
    local orderInfo = json.decode(pOrderInfo)
    local options = json.decode(pPluginOptions)

    -- 判断是否有sid
    if options.sid == "" then
        return json.encode({
            err_code = 500,
            err_message = "请输入SID"
        })
    end

    if options.shop_id == "" then
        return json.encode({
            err_code = 500,
            err_message = "请输入商户ID"
        })
    end

    if options.aid == "" then
        return json.encode({
            err_code = 500,
            err_message = "请输入账号ID"
        })
    end
    -- 构建请求URL和参数
    local url
    local result
    if options.account_type == "1" then
        url = "https://payapp.wechatpay.cn/receiptmdmgr/receipt/create"
        url = url .. "?miniprogram_version=3.15.9"
        url = url .. "&fee=" .. orderInfo.trade_amount
        url = url .. "&remark=" .. orderInfo.order_id
        url = url .. "&remark_pic_urls="
        url = url .. "&option_list=%5B%5D"
        url = url .. "&receipt_item_list=%5B%5D"
        url = url .. "&shop_id=" .. options.shop_id
        url = url .. "&account_id=" .. options.aid
        url = url .. "&account_type=1"
        url = url .. "&sid=" .. options.sid

        log.debug(string.format("[插件] (%s) 创建订单 URL: %s", plugin.info.name, url))

        result = http.get(url, {
            headers = {
                ["xweb_xhr"] = "1",
                ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
                ["Content-Type"] = "application/json",
                ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
                ["Accept-Language"] = "zh-CN,zh;q=0.9"
            }
        })
    elseif options.account_type == "3" then
        url = "https://payapp.wechatpay.cn/receiptsjtmgr/receipt/create"
        url = url .. "?account_type=3"
        url = url .. "&account_id=" .. options.aid
        url = url .. "&sid=" .. options.sid

        local payload = {
            miniprogram_version = "3.15.10",
            fee = orderInfo.trade_amount,
            remark = orderInfo.order_id,
            remark_pic_urls = "",
            option_list = {},
            receipt_item_list = {},
            shop_id = tonumber(options.shop_id),
            sid = options.sid
        }

        log.debug(string.format("[插件] (%s) 创建订单 URL: %s", plugin.info.name, url))
        log.debug(string.format("[插件] (%s) 创建订单 Payload: %s", plugin.info.name, json.encode(payload)))

        result = http.post(url, {
            headers = {
                ["xweb_xhr"] = "1",
                ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
                ["Content-Type"] = "application/json",
                ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
                ["Accept-Language"] = "zh-CN,zh;q=0.9"
            },
            body = json.encode(payload)
        })
    end

    log.debug(string.format("[插件] (%s) 创建订单 GET %s", plugin.info.name, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = string.format("请求失败,状态码:%d", result.status_code)
        })
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return json.encode({
            err_code = 500,
            err_message = "解析返回数据失败"
        })
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return json.encode({
            err_code = 500,
            err_message = response.msg or "创建订单失败"
        })
    end

    -- 提取receipt_id
    local receipt_id
    if response.data then
        if response.data.receipt then
            receipt_id = response.data.receipt.receipt_id
        end
    end
    if not receipt_id then
        return json.encode({
            err_code = 500,
            err_message = "未获取到receipt_id"
        })
    end

    -- 构建获取二维码URL
    local base_url = "https://payapp.wechatpay.cn"
    url = base_url .. (options.account_type == "3" and "/receiptsjtmgr" or "/receiptmdmgr") .. "/receipt/getwxacode"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&wxacode_path_type=1"
    url = url .. "&receipt_id=" .. receipt_id
    url = url .. "&account_id=" .. options.aid
    url = url .. "&account_type=" .. options.account_type
    url = url .. "&sid=" .. options.sid

    log.debug(string.format("[插件] (%s) 获取二维码 URL: %s", plugin.info.name, url))

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    log.debug(string.format("[插件] (%s) 获取二维码 GET %s", plugin.info.name, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = string.format("请求失败,状态码:%d", result.status_code)
        })
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return json.encode({
            err_code = 500,
            err_message = "解析返回数据失败"
        })
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return json.encode({
            err_code = 500,
            err_message = response.msg or "获取二维码失败"
        })
    end

    -- 提取二维码
    if not response.data then
        return json.encode({
            err_code = 500,
            err_message = "返回数据格式错误,缺少data字段"
        })
    end

    local qrcode = response.data.qrcode
    if not qrcode then
        return json.encode({
            err_code = 500,
            err_message = "未获取到二维码"
        })
    end

    if qrcode == "" then
        return json.encode({
            err_code = 500,
            err_message = "二维码内容为空"
        })
    end

    -- 将base64转为图片文件
    local write, filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return json.encode({
            err_code = 500,
            err_message = "二维码保存失败"
        })
    end

    return json.encode({
        type = "qrcode",
        qrcode_file = filePath,
        url = "",
        content = "",
        out_trade_no = tostring(receipt_id),
        err_code = 200,
        err_message = ""
    })

end

-- 支付回调
function plugin.notify(request, orderInfo, params, pluginOptions)
    -- 判断请求方式
    return json.encode({
        error_code = 500,
        error_message = "暂不支持",
        response = ""
    })

end

-- 获取账号列表
function plugin.getAccountList(sid)
    local url = "https://payapp.wechatpay.cn/receiptwxmgr/account/list"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&sid=" .. sid

    local result = http.get(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9"
        }
    })

    -- 判断返回状态
    if result.status_code ~= 200 then
        return nil, string.format("请求账号列表失败,状态码:%d", result.status_code)
    end

    print(result.body)

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return nil, "解析账号列表数据失败"
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return nil, response.msg or "获取账号列表失败"
    end

    -- 返回账号列表数据
    if response.data and response.data.account_list then
        return response.data.account_list, nil
    end

    return nil, "账号列表为空"
end

-- 客户端心跳上报处理
function plugin.heartbeat(pChannelAccount, pHeartbeatRequest)
    local channelAccount = json.decode(pChannelAccount)
    -- 打印心跳数据
    log.info(string.format("(%s) 心跳数据: %s", channelAccount.plugin_name, pHeartbeatRequest))

    -- 解析心跳数据
    local heartbeatData = json.decode(pHeartbeatRequest)
    if heartbeatData == nil or heartbeatData.ext_data == nil or heartbeatData.ext_data == "" then
        return json.encode({
            err_code = 500,
            err_message = "心跳数据解析失败"
        })
    end

    -- 解析扩展数据
    local extData = json.decode(heartbeatData.ext_data)
    log.info(string.format("(%s) 心跳扩展数据 sid:%s", channelAccount.plugin_name, extData.sid))

    -- 保存配置
    helper.channel_account_set_option(channelAccount.id, "sid", extData.sid)

    -- 如果离线状态 则设置为在线
    if channelAccount.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(channelAccount.id)
    end

    return json.encode({
        err_code = 200,
        err_message = "心跳正常"
    })
end

-- 通道新增或修改
function plugin.accountChanged(pAccountInfo)
    local vAccountInfo = json.decode(pAccountInfo)
    return plugin.cron(pAccountInfo, vAccountInfo.options)
end

-- 定时任务
function plugin.cron(pAccountInfo, pPluginOptions)
    local accountInfo = json.decode(pAccountInfo)
    local options = json.decode(pPluginOptions)

    -- 判断是否有SID 
    if options.sid == "" then
        if accountInfo.online == 1 then
            -- 设置离线
            helper.channel_account_offline(accountInfo.id)
        end

        return json.encode({
            err_code = 500,
            err_message = "暂未填写sid"
        })
    end

    -- 判断是否需要获取账号列表
    if options.account_list == "" then
        -- 获取账号列表
        local accountList, err = plugin.getAccountList(options.sid)
        if err then
            helper.channel_account_offline(accountInfo.id)
            return json.encode({
                err_code = 500,
                err_message = err
            })
        end

        -- 保存账号列表
        if accountList then
            local lines = {}
            for _, account in ipairs(accountList) do
                local line = string.format("账号ID:%s|账号类型:%s|商户名称:%s", account.account_id or "",
                    account.account_type or "", account.account_name or "")
                table.insert(lines, line)
            end
            local accountListStr = table.concat(lines, "\n")
            helper.channel_account_set_option(accountInfo.id, "account_list", accountListStr)

            -- 如果只有一个账号，则自动选择第一个账号
            if #accountList > 0 then
                helper.channel_account_set_option(accountInfo.id, "aid", accountList[1].account_id)
                helper.channel_account_set_option(accountInfo.id, "account_type", accountList[1].account_type)
                options.aid = accountList[1].account_id
                options.account_type = tostring( accountList[1].account_type)

                log.info(string.format("(%s) 账号列表获取成功 自动选择账号ID:%s,账号类型:%s",
                    accountInfo.id, options.aid, options.account_type))
            end
        end
    end

    -- 判断用户是否选择了aid
    if options.aid == "" then
        -- 设置离线
        helper.channel_account_offline(accountInfo.id)

        return json.encode({
            err_code = 500,
            err_message = "请选择一个账号"
        })
    end

    -- 判断account_type
    if options.account_type == "" then
        -- 设置离线
        helper.channel_account_offline(accountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = "请选择一个账号类型"
        })
    end

    -- 判断是否有 shop_id
    if options.shop_id == "" then
        local shop_id = plugin._get_shop_id(options.sid, options.aid, options.account_type)
        if shop_id then
            helper.channel_account_set_option(accountInfo.id, "shop_id", shop_id)
            options.shop_id = shop_id
        else
            return json.encode({
                err_code = 500,
                err_message = "获取商户ID失败"
            })
        end
    end

    -- 如果离线状态 则设置为在线
    if accountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(accountInfo.id)
    end

    return json.encode({
        err_code = 200,
        err_message = "处理完成"
    })
end

plugin._get_shop_id = function(sid, account_id, account_type)
    local url
    if account_type == "1" then
        url = string.format(
                "https://payapp.wechatpay.cn/receiptmdmgr/account/get?miniprogram_version=3.15.10&account_id=%s&account_type=%s&sid=%s",
                account_id, account_type, sid)
    elseif account_type == "3" then
        url = string.format(
                "https://payapp.wechatpay.cn/receiptsjtmgr/account/get?miniprogram_version=3.15.10&account_id=%s&account_type=%s&sid=%s",
                account_id, account_type, sid)
    else
        return nil
    end

    local headers = {
        ["xweb_xhr"] = "1",
        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
        ["Content-Type"] = "application/json",
        ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
        ["Accept-Language"] = "zh-CN,zh;q=0.9"
    }

    local resp = http.get(url, {
        headers = headers
    })

    if resp == nil then
        log.warning(string.format("(%s) 获取商户ID失败,请求失败", account_id, url))
        return nil
    end

    if resp.status_code ~= 200 then
        log.warning(string.format("(%s) 获取商户ID失败,状态码:%d", account_id, resp.status_code))
        return nil
    end

    if resp.body == "" then
        log.warning(string.format("(%s) 获取商户ID失败,返回数据为空", account_id))
        return nil
    end

    local data = json.decode(resp.body)

    if data.errcode ~= 0 then
        log.warning(string.format("(%s) 获取商户ID失败,错误码:%d", account_id, data.errcode))
        return nil
    end

    if data.data and data.data.auth_shop_list and #data.data.auth_shop_list > 0 then
        return data.data.auth_shop_list[1].shop_id
    end

    return nil

end
