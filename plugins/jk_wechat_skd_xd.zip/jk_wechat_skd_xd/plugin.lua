-- 载入插件
local currentPath = debug.getinfo(1, "S").source:sub(2)
local projectDir = currentPath:match("(.*/)")
package.path = package.path .. ";." .. projectDir .. "../../common/?.lua"

local funcs = require("funcs")
local http = require("http")
local json = require("json")
local log = require("log")
local helper = require("helper")

-- 定义常量
PAY_WXPAY_SKD_XD = "jk_wechat_skd_xd"

--- 插件信息
plugin = {
    info = {
        name = PAY_WXPAY_SKD_XD,
        title = '微信收款单-XD监控端',
        author = '',
        description = "监控插件",
        link = '',
        version = "1.4.5",
        -- 支持支付类型
        channels = {
            wxpay = {{
                label = '微信收款单-XD监控端',
                value = PAY_WXPAY_SKD_XD,
                -- 支持上报
                report = 1,
                options = {
                    bind_client_name = 1,
                }
            }}
        },
        options = {
            _ = ""
        }

    }
}

function plugin.pluginInfo()
    return json.encode(plugin.info)
end

-- 获取form表单
function plugin.formItems(payType, payChannel)
    return json.encode({
        inputs = {{
            name = 'sid',
            label = 'SID',
            type = 'input',
            default = "",
            options = {
                tip = ''
            },
            placeholder = "请输入SID",
            rules = {{
                required = true,
                trigger = {"input", "blur"},
                message = "请输入SID"
            }}
        }, {
            name = 'shop_id',
            label = '商户ID',
            type = 'input',
            default = "",
            options = {
                tip = ''
            },
            placeholder = "请输入商户ID",
            rules = {{
                required = true,
                trigger = {"input", "blur"},
                message = "请输入商户ID"
            }}
        }, {
            name = 'aid',
            label = '账号ID',
            type = 'input',
            default = "",
            placeholder = "请输入账号ID",
            rules = {{
                required = true,
                trigger = {"input", "blur"},
                message = "请输入账号ID"
            }}
        }}
    })
end

-- 创建订单
function plugin.create(pOrderInfo, pPluginOptions, pAccountInfo, pDeviceInfo)
    local orderInfo = json.decode(pOrderInfo)
    local options = json.decode(pPluginOptions)

    -- 判断是否有sid
    if options.sid == "" then
        return json.encode({
            err_code = 500,
            err_message = "请输入SID"
        })
    end

    if options.shop_id == "" then
        return json.encode({
            err_code = 500,
            err_message = "请输入商户ID"
        })
    end

    if options.aid == "" then
        return json.encode({
            err_code = 500,
            err_message = "请输入账号ID"
        })
    end

    -- 构建请求URL
    local url = "https://payapp.wechatpay.cn/receiptmdmgr/receipt/create"
    url = url .. "?miniprogram_version=3.15.9"
    url = url .. "&fee=" .. orderInfo.trade_amount
    url = url .. "&remark=" .. orderInfo.order_id
    url = url .. "&remark_pic_urls="
    url = url .. "&option_list=%5B%5D"
    url = url .. "&receipt_item_list=%5B%5D"
    url = url .. "&shop_id=" .. options.shop_id
    url = url .. "&account_id=" .. options.aid
    url = url .. "&account_type=1"
    url = url .. "&sid=" .. options.sid

    log.debug(string.format("[插件] (%s) 创建订单 URL: %s", plugin.info.name, url))

    local result = http.get(url,{
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9",
        }
    })

    log.debug(string.format("[插件] (%s) 创建订单 GET %s", plugin.info.name, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = string.format("请求失败,状态码:%d", result.status_code)
        })
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return json.encode({
            err_code = 500,
            err_message = "解析返回数据失败"
        })
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return json.encode({
            err_code = 500,
            err_message = response.msg or "创建订单失败"
        })
    end

    -- 提取receipt_id
    local receipt_id
    if response.data then
        if response.data.receipt then
            receipt_id = response.data.receipt.receipt_id
        end
    end
    if not receipt_id then
        return json.encode({
            err_code = 500,
            err_message = "未获取到receipt_id"
        })
    end

    -- 构建获取二维码URL
    local url = "https://payapp.wechatpay.cn/receiptmdmgr/receipt/getwxacode"
    url = url .. "?miniprogram_version=3.15.10"
    url = url .. "&wxacode_path_type=1"
    url = url .. "&receipt_id=" .. receipt_id
    url = url .. "&account_id=" .. options.aid
    url = url .. "&account_type=1"
    url = url .. "&sid=" .. options.sid

    log.debug(string.format("[插件] (%s) 获取二维码 URL: %s", plugin.info.name, url))

    local result = http.get(url,{
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Accept"] = "*/*",
            ["Referer"] = "https://servicewechat.com/wx264e9b6d4d484f51/186/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9",
        }
    })

    log.debug(string.format("[插件] (%s) 获取二维码 GET %s", plugin.info.name, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = string.format("请求失败,状态码:%d", result.status_code)
        })
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return json.encode({
            err_code = 500,
            err_message = "解析返回数据失败"
        })
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return json.encode({
            err_code = 500,
            err_message = response.msg or "获取二维码失败"
        })
    end

    -- 提取二维码
    if not response.data then
        return json.encode({
            err_code = 500,
            err_message = "返回数据格式错误,缺少data字段"
        })
    end

    local qrcode = response.data.qrcode
    if not qrcode then
        return json.encode({
            err_code = 500,
            err_message = "未获取到二维码"
        })
    end

    if qrcode == "" then
        return json.encode({
            err_code = 500,
            err_message = "二维码内容为空"
        })
    end

    -- 将base64转为图片文件
    local write,filePath = helper.save_image_cache_base64(qrcode)
    if not write then
        return json.encode({
            err_code = 500, 
            err_message = "二维码保存失败"
        })
    end



    return json.encode({
        type = "qrcode",
        qrcode_file = filePath,
        url = "",
        content = "",
        out_trade_no = tostring(receipt_id),
        err_code = 200,
        err_message = ""
    })

end

-- 支付回调
function plugin.notify(request, orderInfo, params, pluginOptions)
    -- 判断请求方式
    return json.encode({
        error_code = 500,
        error_message = "暂不支持",
        response = ""
    })

end

-- 解析上报数据
function plugin.parseMsg(msg)
    -- 匹配到金额
    return json.encode({
        err_code = 500,
        err_message = "无需上报"
    })

end

-- 客户端心跳上报处理
function plugin.heartbeat(pChannelAccount, pHeartbeatRequest)
    local channelAccount = json.decode(pChannelAccount)
    -- 打印心跳数据
    log.info(string.format("(%s) 心跳数据: %s",channelAccount.plugin_name, pHeartbeatRequest))

    -- 解析心跳数据
    local heartbeatData = json.decode(pHeartbeatRequest)
    if heartbeatData == nil or heartbeatData.ext_data == nil or heartbeatData.ext_data == "" then
        return json.encode({
            err_code = 500,
            err_message = "心跳数据解析失败"
        })
    end

    -- 解析扩展数据
    local extData = json.decode(heartbeatData.ext_data)
    log.info(string.format("(%s) 心跳扩展数据 sid:%s aid:%s shop_id:%s", channelAccount.plugin_name, extData.sid,
        extData.aid, extData.shop_id))

    -- 保存配置
    helper.channel_account_set_option(channelAccount.id, "sid", extData.sid)
    helper.channel_account_set_option(channelAccount.id, "shop_id", extData.shop_id)
    helper.channel_account_set_option(channelAccount.id, "aid", extData.aid)

    return json.encode({
        err_code = 200,
        err_message = "心跳正常"
    })

end

