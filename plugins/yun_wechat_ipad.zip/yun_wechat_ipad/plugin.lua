local currentPath = debug.getinfo(1, "S").source:sub(2)
local projectDir = currentPath:match("(.*/)")
package.path = package.path .. ";." .. projectDir .. "../../common/?.lua"

local funcs = require("funcs")
local http = require("http")
local json = require("json")
local xml = require("xml")
local helper = require("helper")
local orderHelper = require("orderHelper")
local websocket = require("websocket")
local log = require("log")

PAY_CHANNEL_CODE_YUN_WECHAT_IPAD = "yun_wechat_ipad"
--- 插件信息
plugin = {
    info = {
        name = PAY_CHANNEL_CODE_YUN_WECHAT_IPAD,
        title = '微信-IPAD',
        author = '匿名',
        description = "微信-IPAD 仅供学习写法,切勿使用",
        link = '',
        version = "1.4.8.12",
        -- 最小支持主程序版本号
        min_main_version = "1.4.8.12",
        -- 支持支付类型
        channels = {
            wxpay = {
                {
                    label = '微信-IPAD',
                    value = PAY_CHANNEL_CODE_YUN_WECHAT_IPAD,
                    options = {
                        -- 使用递增金额
                        use_add_amount = 1,
                        -- 使用二维码登录流程
                        use_qrcode_login = 1,
                        -- 增加账号操作
                        actions = {
                            {
                                label = "唤醒",
                                func = "action_wake", -- 为空则无操作
                                type = "confirm", -- 操作类型 click:点击触发 confirm: 弹出是否确认 prompt: 输入内容 form: 弹出输入框
                                -- form_items = {}, -- 是否需要输入内容格式跟formItems一致 待实现
                                options = {
                                    tip = "是否需要唤醒", -- 如果为 confirm,prompt 就弹出此内容为提示
                                }
                            }
                        }
                    },
                    info = "微信 IPAD方式登录",
                }
            }
        },
        options = {
            -- 启动定时查询在线状态
            detection_interval = 6,
            detection_type = "cron", --- order 单订单检查 cron 定时执行任务
            -- 配置项
            options = {
                {
                    title = "密钥", key = "key", default = ""
                },

            }
        }

    }
}

function plugin.pluginInfo()
    return json.encode(plugin.info)
end

-- 获取form表单
function plugin.formItems(payType, payChannel)
    return json.encode({
        inputs = {
            {
                name = 'gateway',
                label = '选择网关',
                type = 'select',
                default = "",
                options = {
                    tip = '',
                    -- 选择网关
                    chose_gateway = 1
                },
                placeholder = "请选址网关",
                rules = { {
                              required = true,
                              trigger = { "input", "blur" },
                              message = "请选择"
                          } }
            },
            {
                name = 'proxy_type',
                label = '代理模式',
                type = 'radio',
                default = "platform",
                options = {
                    tip = '选择使用的代理方式',
                },
                placeholder = "请选择代理模式",
                values = {
                    {
                        label = "使用平台代理池",
                        value = "platform"
                    },
                    {
                        label = "不使用代理",
                        value = "none"
                    },
                    {
                        label = "使用自己的代理",
                        value = "self"
                    },
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请选择代理模式"
                    }
                }
            },
            {
                name = 'proxy_pool_id',
                label = '绑定代理池',
                type = 'chose_proxy_pool',
                default = "-1",
                options = {
                    tip = '',
                },
                placeholder = "请选择绑定的代理池",
                when = "this.formModel.options.proxy_type == 'platform'",
            },
            {
                name = 'proxy_pool_item_id',
                label = '绑定代理',
                type = 'input',
                hidden = 1,
                default = "",
                options = {
                    tip = '',
                },
                placeholder = "请选择绑定的代理池",
                when = "this.formModel.options.proxy_type == 'platform'",
            },
            {
                name = 'proxy_url',
                label = '代理地址',
                type = 'input',
                default = "",
                options = {
                    tip = '格式: http://user:pass@host:port 或 socks5://user:pass@host:port',
                },
                placeholder = "请输入代理地址",
                when = "this.formModel.options.proxy_type == 'self'",
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入代理地址"
                    }
                }
            },
            {
                name = 'client_id',
                label = '客户端ID',
                type = 'input',
                default = "",
                options = {
                    tip = '不需要填写, 除非登录失败后再清空'
                }
            },
            {
                name = 'qrcode_type',
                label = '码方式',
                type = 'radio',
                default = "platform",
                options = {
                    tip = '',
                },
                placeholder = "请选择收款码类型",
                values = {
                    {
                        label = "自动生成",
                        value = "platform"
                    },
                    {
                        label = "个人上传",
                        value = "self"
                    },
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'qrcode',
                label = '收款码地址',
                type = 'input',
                default = "",
                placeholder = "请输入收款码地址",
                when = "this.formModel.options.qrcode_type == 'self' && this.formModel.options.type == 'url'",
                options = {
                    append_deqrocde = 1, -- 增加解析二维码功能
                    tip = '',
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'qrcode_file',
                label = '收款码图片',
                type = 'image',
                default = "",
                options = {
                    tip = '',
                },
                placeholder = "请上传收款码图片",
                when = "this.formModel.options.qrcode_type == 'self' && this.formModel.options.type == 'image'",
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
            {
                name = 'type',
                label = '收款码类型',
                type = 'select',
                default = "url",
                options = {
                    tip = '',
                },
                placeholder = "请选择收款码类型",
                when = "this.formModel.options.qrcode_type == 'self' ",
                values = {
                    {
                        label = "地址",
                        value = "url"
                    },
                    {
                        label = "图片",
                        value = "image"
                    },
                },
                rules = {
                    {
                        required = true,
                        trigger = { "input", "blur" },
                        message = "请输入"
                    }
                }
            },
        }
    })
end

-- 创建订单
-- pOrderInfo 订单信息
-- pluginOptions 插件配置
-- pAccountInfo 账号信息
-- pDeviceInfo 设备信息
function plugin.create(pOrderInfo, pluginOptions, pAccountInfo, pDeviceInfo)
    local vParams = json.decode(pluginOptions)
    local orderInfo = json.decode(pOrderInfo)
    local vAccountInfo = json.decode(pAccountInfo)
    local vAccountOptions = json.decode(vAccountInfo.options)

    if vAccountInfo.online ~= 1 then
        return json.encode({
            err_code = 500,
            err_message = "账号已离线"
        })
    end

    if vAccountOptions["qrcode_type"] ~= nil and vAccountOptions["qrcode_type"] == "self" then
        if vAccountOptions['type'] == 'image' then
            return json.encode({
                type = "qrcode",
                qrcode_file = vAccountOptions['qrcode_file'],
                url = "",
                content = "",
                out_trade_no = '',
                err_code = 200,
                err_message = ""
            })
        end

        return json.encode({
            type = "qrcode",
            qrcode = " "..vAccountOptions['qrcode'].." '",
            url = "",
            content = "",
            out_trade_no = '',
            err_code = 200,
            err_message = ""
        })
    end

    -- 获取服务端地址
    local serverAddress = helper.channel_gateway_addr(vParams.gateway)
    if serverAddress == "" then
        return json.encode({
            err_code = 500,
            err_message = "暂未配置支付网关"
        })
    end

    local apiUri = string.format('%s/pay/GeneratePayQCode?key=%s', serverAddress, vAccountOptions.client_id)

    local response, error_message = http.request("POST", apiUri, {
        body = json.encode({
            Name = orderInfo.order_id,
            Money = string.format("%d", orderInfo.trade_amount)
        }),
        timeout = "30s",
        headers = {
            ["content-type"] = "application/json"
        }
    })

    if response.status_code ~= 200 then
        if vAccountInfo.online == 1 then
            -- 设置离线
            helper.channel_account_offline(vAccountInfo.id)
        end
        return json.encode({
            err_code = 500,
            err_message = "创建订单失败"
        })
    end

    log.debug("创建订单返回内容", response.body)
    local returnInfo = json.decode(response.body)

    if returnInfo.Code == nil then
        -- 设置离线
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = string.format('请求响应错误,响应内容: %v', response.body)
        })
    end

    if returnInfo.Code ~= 200 then
        -- 设置离线
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = returnInfo.Text
        })
    end

    -- 判断是否创建了二维码
    if returnInfo.Data.pay_url ~= nil and returnInfo.Data.pay_url ~= "" and returnInfo.Data.retmsg == "ok" then

        -- 解析 pay_url 获取 url 参数
        local pay_url = returnInfo.Data.pay_url
        local url_param = pay_url

        -- 使用 url.parse 解析支付链接
        local parsed ,parsed_url =helper.url_parse(pay_url)
        if parsed and parsed_url ~= nil and   parsed_url.host == "api.pwmqr.com"  then
            -- 从查询参数中获取 url 参数
            if parsed_url.query and parsed_url.query.url then
                url_param = parsed_url.query.url
                log.debug("解析到的支付链接", url_param)
            end
        end

        return json.encode({
            type = "qrcode",
            qrcode = url_param,
            url = "",
            content = "",
            out_trade_no = '',
            err_code = 200,
            err_message = ""
        })
    end
    return json.encode({
        err_code = 500,
        err_message = "创建收款码失败"
    })

end

-- 定时任务
function plugin.cron(pAccountInfo, pPluginOptions)
    local vAccountInfo = json.decode(pAccountInfo)
    local vAccountOption = json.decode(vAccountInfo.options)

    if vAccountOption.client_id == "" then
        if vAccountInfo.online == 1 then
            -- 设置离线
            helper.channel_account_offline(vAccountInfo.id)
        end

        return json.encode({
            err_code = 500,
            err_message = "未登录"
        })
    end

    -- 获取服务端地址
    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return json.encode({
            err_code = 500,
            err_message = "暂未配置支付网关"
        })
    end

    -- 获取登录状态 /login/GetLoginStatus
    local apiUri = string.format('%s/login/GetLoginStatus?key=%s', serverAddress, vAccountOption.client_id)
    local response, error_message = http.request("GET", apiUri, {
        timeout = "30s",headers = {
            ["accept"] = "application/json",
            ["content-type"] = "application/json"
        }
    })

    if response == nil then
        log.error("请求获取登录状态失败", error_message)
        return json.encode({
            err_code = 500,
            err_message = "请求网关失败"
        })
    end

    if response.status_code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = "请求网关失败"
        })
    end


    local loginStatus = json.decode(response.body)
    if loginStatus.Code ~= 200 then
        -- 设置离线
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = string.format("登录状态异常: %s", loginStatus.Message or "未知错误")
        })
    end

    -- 设置在线
    if vAccountInfo.online ~= 1 then
        helper.channel_account_online(vAccountInfo.id)
    end


    -- 判断websocket是否正常
    if vAccountOption.websocket_conn_id ~= nil and vAccountOption.websocket_conn_id ~= "" then
        local conn_id,err = websocket.active(vAccountOption.websocket_conn_id)
        if err and err ~= "" then
            log.info("连接失败,需要重连: " .. err)
            websocket.close(vAccountOption.websocket_conn_id)
            vAccountOption.websocket_conn_id = ""
            helper.channel_account_set_option(vAccountInfo.id, "websocket_conn_id", "")
        end
    end

    -- 判断是否需要重连
    if vAccountOption.websocket_conn_id == nil or vAccountOption.websocket_conn_id == "" then
        local url = string.format("%s/ws/GetSyncMsg?key=%s", string.gsub(string.gsub(serverAddress, "http://", "ws://"), "https://", "wss://"), vAccountOption.client_id)
        log.info("websocket地址:",url)
        local conn_id,err = websocket.dial(url,{
            ping_interval = 10,  -- 10秒ping一次
            onMessage = "onMessage",  -- 连接消息
            onError = "onError",      -- 连接错误
            onClose = "onClose",       -- 连接关闭
            onConnect = "onConnect",       -- 连接成功
            options = json.encode({
                id = vAccountInfo.id,
                uid = vAccountInfo.uid
            }), -- 返回参数配置
        })
        if err and err ~= "" then
            log.info("连接失败: " .. err)
            return json.encode({
                err_code = 500,
                err_message = "Websocket连接失败"
            })
        else
            vAccountOption.websocket_conn_id = conn_id
            helper.channel_account_set_option(vAccountInfo.id, "websocket_conn_id", conn_id)
        end

    end

    if vAccountOption.websocket_conn_id ~= "" then
        return json.encode({
            err_code = 200,
            err_message = "Websocket连接处理中"
        })
    end

    -- 获取账单
    local apiUri = string.format('%s/message/HttpSyncMsg?key=%s', serverAddress, vAccountOption.client_id)
    local response, error_message = http.request("POST", apiUri, {
        body = json.encode({
            Count = 0
        }),
        timeout = "30s",
        headers = {
            ["accept"] = "application/json",
            ["content-type"] = "application/json"
        }
    })
    if response == nil then
        log.error("请求获取消息失败", error_message)
        return json.encode({
            err_code = 500,
            err_message = "暂未配置支付网关"
        })
    end

    log.debug("同步消息", response.status_code)

    if response.status_code ~= 200 then
        -- 设置离线
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = string.format('请求错误: %v', response.status_code)
        })
    end

    log.debug("同步消息返回内容", response.body)
    local returnInfo = json.decode(response.body)

    if returnInfo == nil then
        return json.encode({
            err_code = 500,
            err_message = string.format('请求响应错误,响应内容: %v', response.body)
        })
    end

    if returnInfo.Code == nil then
        -- 设置离线
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = string.format('请求响应格式错误,响应内容: %v', response.body)
        })
    end

    if returnInfo.Code ~= 200 then
        -- 设置离线
        helper.channel_account_offline(vAccountInfo.id)
        return json.encode({
            err_code = 500,
            err_message = returnInfo.Text
        })
    end

    -- 如果离线状态 则设置为在线
    if vAccountInfo.online ~= 1 then
        -- 设置在线
        helper.channel_account_online(vAccountInfo.id)
    end

    -- 解析消息
    if returnInfo.Data then
        for i, msg in ipairs(returnInfo.Data) do
            if msg.AddMsgs then
                for j, addMsg in ipairs(msg.AddMsgs) do
                    if addMsg.msg_type == 49 then
                        -- 推送外部订单
                        plugin.parseMsg(vAccountInfo.id, vAccountInfo.uid, addMsg)
                    end
                end
            end
        end
    end

    return json.encode({
        err_code = 200,
        err_message = string.format('处理完成')
    })

end

function plugin.parseMsg(vAccountId,uid, msg)
    -- 解析xml
    local msgData = msg.content.str

    local appMsg = msgData:match("<appmsg([%W%w]+)</appmsg>")
    -- 订单号
    local remark = appMsg:match("<des>%s*<!%[CDATA%[[%w%W]+收款方备注(%d+)[%w%W]+<%/des>%s+<action>")
    -- 发送方
    local title = msgData:match("<appname><!%[CDATA%[(.*)%]%]><%/appname>")
    local content = msgData:match("<title><!%[CDATA%[(.*)%]%]><%/title>%s+<des")
    log.debug("消息内容", msgData)
    log.debug("解析消息", remark, title, content)

    local rules = { {
                        TitleReg = "微信收款助手",
                        ContentReg = "微信支付收款(?<amount>[\\d\\.]+)元(\\(([新老]顾客)?(朋友)?到店\\))?"
                    }, {
                        TitleReg = "微信支付",
                        ContentReg = "微信支付：微信支付收款(?<amount>[\\d\\.]+)元"
                    }, {
                        TitleReg = "微信支付",
                        ContentReg = "个人收款码到账¥(?<amount>[\\d\\.]+)"
                    }, {
                        TitleReg = "微信收款助手",
                        ContentReg = "\\[店员消息\\]收款到账(?<amount>[\\d\\.]+)元"
                    }, {
                        TitleReg = "微信支付",
                        ContentReg = "二维码赞赏到账(?<amount>[\\d\\.]+)元"
                    }, -- 经营码
                    {
                        TitleReg = "微信收款商业版",
                        ContentReg = "收款(?<amount>[\\d\\.]+)元"
                    }, {
                        TitleReg = "收款通知",
                        ContentReg = "微信收款商业版: 收款(?<amount>[\\d\\.]+)元"
                    }, {
                        TitleReg = "微信收款助手",
                        ContentReg = "收款单到账(?<amount>[\\d\\.]+)元"
                    } }
    -- 循环规则
    for i, v in ipairs(rules) do
        -- 判断渠道是否一样的
        -- 匹配标题
        local titleMatched = helper.regexp_match(title, v.TitleReg)
        if titleMatched then
            -- 调用正则
            local matched, matchGroups = helper.regexp_match_group(content, v.ContentReg)

            -- 判断匹配是否成功
            if matched == true then
                -- 解析正则中的价格
                matchGroups = json.decode(matchGroups)
                -- 判断是否解析成功
                if matchGroups['amount'] and #matchGroups['amount'] > 0 then
                    -- 避免精度有问题
                    local price = math.floor((matchGroups['amount'][1] + 0.000005) * 100)
                    orderHelper.report({
                        id = vAccountId,
                        uid = uid,
                    }, {
                        amount = price,
                        pay_type = "wxpay",
                        channel_code = PAY_CHANNEL_CODE_YUN_WECHAT_IPAD,
                        pay_time = msg.create_time,
                        out_order_id = remark
                    })

                end
            end

        end

    end

end

-- 二维码登录
function plugin.login_qrcode(pAccountInfo, pUserInfo, pParams)
    local vParams = json.decode(pParams)
    local vAccountInfo = json.decode(pAccountInfo)
    local vAccountOption = json.decode(vAccountInfo.options)
    local vUserInfo = json.decode(pUserInfo)

    -- 获取服务端地址
    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return json.encode({
            err_code = 500,
            err_message = "暂未配置支付网关"
        })
    end
    local client_id = ""

    -- 检查是否已有client_id
    if vAccountOption.client_id and vAccountOption.client_id ~= "" then
        -- 如果已有client_id，则直接使用
        client_id = vAccountOption.client_id
        log.debug("使用现有客户端ID", client_id)
    else
        -- 如果没有client_id，则创建新客户端
        local key = helper.get_plugin_option(plugin.info.name, "key", "")
        -- 1. 创建客户端
        local apiUri = string.format('%s/admin/GenAuthKey1?key=%s', serverAddress, key)

        log.debug("创建客户端请求", apiUri)
        local req = {
            Count = 1,
            Days = 180
        }

        local response, error_message = http.request("POST", apiUri, {
            timeout = "30s",
            body = json.encode(req),
            headers = {
                ["content-type"] = "application/json"
            }
        })

        if error_message ~= nil then
            return json.encode({
                err_code = 500,
                err_message = string.format('请求错误: %v', error_message)
            })
        end

        local returnInfo = json.decode(response.body)
        print("创建客户端返回内容", response.body)
        if returnInfo.Code == nil then
            return json.encode({
                err_code = 500,
                err_message = string.format('请求响应错误,响应内容: %v', response.body)
            })
        end
        if returnInfo.Code ~= 200 then
            return json.encode({
                err_code = 500,
                err_message = string.format('返回错误状态码 响应内容: %v', response.body)
            })
        end

        client_id = returnInfo.Data[1]
    end

    local proxyUrl = ""
    -- 根据代理模式选择代理
    if vAccountOption.proxy_type == "platform" and tonumber(vAccountOption.proxy_pool_id) > 0 then
        -- 使用平台代理池
        local proxyItem = helper.proxy_pool_fetch(tonumber(vAccountOption.proxy_pool_id), tonumber(vAccountOption.proxy_pool_item_id))
        if proxyItem ~= nil then
            log.info("获取到代理",
                    string.format([[proxy_id: %s
proxy_type: %s
proxy_address: %s
proxy_port: %s
proxy_username: %s
proxy_password: %s
proxy_url: %s ]],proxyItem.proxy_id,proxyItem.proxy_type,proxyItem.proxy_address,proxyItem.proxy_port,proxyItem.proxy_username,proxyItem.proxy_password,proxyItem.proxy_url))

            if proxyItem.proxy_id ~= vAccountOption.proxy_pool_item_id  then
                -- 保存代理配置 以便下次使用
                helper.channel_account_set_option(vAccountInfo.id, "proxy_pool_item_id", proxyItem.proxy_id)
            end
            proxyUrl = proxyItem.proxy_url
        elseif tonumber(vAccountOption.proxy_pool_item_id) > 0 then
            -- 清理代理关系
            helper.proxy_pool_release(tonumber(vAccountOption.proxy_pool_item_id))
        end
    elseif vAccountOption.proxy_type == "self" and vAccountOption.proxy_url and vAccountOption.proxy_url ~= "" then
        -- 使用自定义代理
        proxyUrl = vAccountOption.proxy_url
        log.info("使用自定义代理", proxyUrl)
    elseif vAccountOption.proxy_type == "none" then
        -- 不使用代理
        log.info("不使用代理")
    end

    -- 2. 获取登录二维码
    local apiUri = string.format('%s/login/GetLoginQrCodeNew?key=%s', serverAddress, client_id)
    local response, error_message = http.request("POST", apiUri, {
        body = json.encode({
            Check = false,
            Proxy = proxyUrl
        }),
        headers = {
            ["content-type"] = "application/json"
        },
        timeout = "30s"
    })

    if error_message ~= nil then
        return json.encode({
            err_code = 500,
            err_message = string.format('请求获取登录二维码错误: %v', error_message)
        })
    end

    returnInfo = json.decode(response.body)
    if returnInfo.Code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = string.format('返回错误状态码: %v', response.body)
        })
    end

    log.debug("获取登录二维码成功", response.body)
    local qrcode = returnInfo.Data.QrCodeUrl

    -- 使用 url.parse 解析登录链接
    local parsed ,parsed_url =helper.url_parse(qrcode)
    if parsed and parsed_url ~= nil and   parsed_url.host == "api.pwmqr.com"  then
        -- 从查询参数中获取 url 参数
        if parsed_url.query and parsed_url.query.url then
            qrcode = parsed_url.query.url
            log.debug("获取到登录链接", qrcode)
        end
    end

    return json.encode({
        -- 返回二维码
        qrcode = qrcode,
        -- 返回二维码相关参数 check 会一并携带返回
        options = {
            client_id = client_id
        },
        err_code = 200,
        err_message = ""
    })

end

-- 检查二维码登录状态
function plugin.login_qrcode_check(pAccountInfo, pUserInfo, pParams)
    local vParams = json.decode(pParams)
    local vAccountInfo = json.decode(pAccountInfo)
    local vAccountOption = json.decode(vAccountInfo.options)
    -- 获取服务端地址
    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return json.encode({
            err_code = 500,
            err_message = "暂未配置支付网关"
        })
    end

    local apiUri = string.format('%s/login/CheckLoginStatus?key=%s', serverAddress, vParams.client_id)

    log.debug(" 检查二维码登录状态", apiUri)
    local response, error_message = http.request("GET", apiUri, {
        timeout = "30s",
        headers = {
            ["accept"] = "application/json"
        }
    })

    if error_message ~= nil then
        return json.encode({
            err_code = 500,
            err_message = string.format('请求错误: %v', error_message)
        })
    end

    local returnInfo = json.decode(response.body)
    if returnInfo.Code == nil then
        return json.encode({
            err_code = 500,
            err_message = string.format('请求响应错误,响应内容: %v', response.body)
        })
    end
    if returnInfo.Code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = returnInfo.Text
        })
    end

    if returnInfo.Data.state == 1 then
        return json.encode({
            err_code = 201,
            err_message = string.format('扫码中')
        })
    end

    if returnInfo.Data.state == 2 then
        helper.channel_account_set_option(vAccountInfo.id, "client_id",  vParams.client_id)

        return json.encode({
            err_code = 200,
            err_message = string.format('登录成功 %s', returnInfo.Data.nick_name),
            data = {
                can_bind_token = false
            }
        })
    end

    return json.encode({
        err_code = 201,
        err_message = string.format('等待扫码')
    })

end


-- 唤醒
function plugin.action_wake(pAccountInfo,pUserInfo,pParams)
    local vAccountInfo = json.decode(pAccountInfo)
    local vAccountOption = json.decode(vAccountInfo.options)

    -- 获取服务端地址
    local serverAddress = helper.channel_gateway_addr(vAccountOption.gateway)
    if serverAddress == "" then
        return json.encode({
            err_code = 500,
            err_message = "暂未配置支付网关"
        })
    end

    local proxyUrl = ""
    -- 根据代理模式选择代理
    if vAccountOption.proxy_type == "platform" and tonumber(vAccountOption.proxy_pool_id) > 0 then
        -- 使用平台代理池
        local proxyItem = helper.proxy_pool_fetch(tonumber(vAccountOption.proxy_pool_id), tonumber(vAccountOption.proxy_pool_item_id))
        if proxyItem ~= nil then
            log.info("获取到代理",
                    string.format([[proxy_id: %s
proxy_type: %s
proxy_address: %s
proxy_port: %s
proxy_username: %s
proxy_password: %s
proxy_url: %s ]],proxyItem.proxy_id,proxyItem.proxy_type,proxyItem.proxy_address,proxyItem.proxy_port,proxyItem.proxy_username,proxyItem.proxy_password,proxyItem.proxy_url))

            if proxyItem.proxy_id ~= vAccountOption.proxy_pool_item_id  then
                -- 保存代理配置 以便下次使用
                helper.channel_account_set_option(vAccountInfo.id, "proxy_pool_item_id", proxyItem.proxy_id)
            end
            proxyUrl = proxyItem.proxy_url
        elseif tonumber(vAccountOption.proxy_pool_item_id) > 0 then
            -- 清理代理关系
            helper.proxy_pool_release(tonumber(vAccountOption.proxy_pool_item_id))
        end
    elseif vAccountOption.proxy_type == "self" and vAccountOption.proxy_url and vAccountOption.proxy_url ~= "" then
        -- 使用自定义代理
        proxyUrl = vAccountOption.proxy_url
        log.info("使用自定义代理", proxyUrl)
    elseif vAccountOption.proxy_type == "none" then
        -- 不使用代理
        log.info("不使用代理")
    end



    -- 发送唤醒请求
    local apiUri = string.format('%s/login/WakeUpLogin?key=%s',serverAddress, vAccountOption.client_id)
    local response, error_message = http.request("POST", apiUri, {
        body = json.encode({
            Check = false,
            Proxy = proxyUrl
        }),
        timeout = "30s",
        headers = {
            ["accept"] = "application/json",
            ["content-type"] = "application/json"
        }
    })

    if response == nil then
        log.error("唤醒请求失败", error_message)
        return json.encode({
            err_code = 500,
            err_message = "唤醒请求失败: " .. (error_message or "未知错误")
        })
    end

    log.info("唤醒请求响应", response.body)

    return json.encode({
        err_code = 200,
        err_message = "唤醒请求已发送"
    })
end





-- 消息处理回调
function plugin.onConnect(connID, pOptions)
    log.info("连接成功"..connID)
    local vOptions = json.decode(pOptions)

    -- 设置离线
    helper.channel_account_online(vOptions.id)
end

-- 消息处理回调
function plugin.onMessage(connID, pOptions, message)
    log.info("收到消息: ", connID, options, message)
    local vOptions = json.decode(pOptions)
    local vMessage = json.decode(message)

    plugin.parseMsg(vOptions.id, vOptions.uid, json.decode(vMessage.data))
end

-- 错误处理回调
function plugin.onError(connID, pOptions, errorMsg)
    log.info("发生错误: " .. errorMsg)
end

-- 连接关闭回调
function plugin.onClose(connID, pOptions, reason)
    log.info("连接关闭: " .. reason)
    -- 设置下线
    local vOptions = json.decode(pOptions)

    -- 设置离线
    helper.channel_account_offline(vOptions.id)

end
