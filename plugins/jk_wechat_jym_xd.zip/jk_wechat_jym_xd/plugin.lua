-- 载入插件
local currentPath = debug.getinfo(1, "S").source:sub(2)
local projectDir = currentPath:match("(.*/)")
package.path = package.path .. ";." .. projectDir .. "../../common/?.lua"

local funcs = require("funcs")
local http = require("http")
local json = require("json")
local log = require("log")
local helper = require("helper")

-- 定义常量
PAY_WXPAY_LINKQRCODE_XD = "jk_wechat_linkqrcode_xd"

--- 插件信息
plugin = {
    info = {
        name = PAY_WXPAY_LINKQRCODE_XD,
        title = '微信收款连接-XD监控端',
        author = '',
        description = "你猜",
        link = '',
        version = "1.4.6.3",
        -- 支持支付类型
        channels = {
            wxpay = {{
                label = '微信收款连接-XD监控端',
                value = PAY_WXPAY_LINKQRCODE_XD,
                -- 支持上报
                report = 1,
                options = {
                    bind_client_name = 1,
                }
            }}
        },
        options = {
            _ = ""
        }

    }
}

function plugin.pluginInfo()
    return json.encode(plugin.info)
end

-- 获取form表单
function plugin.formItems(payType, payChannel)
    return json.encode({
        inputs = {{
            name = 'sid',
            label = 'SID',
            type = 'input',
            default = "",
            options = {
                tip = ''
            },
            placeholder = "请输入SID",
            rules = {{
                required = true,
                trigger = {"input", "blur"},
                message = "请输入SID"
            }}
        }, {
            name = 'shop_id',
            label = '商户ID',
            type = 'input',
            default = "",
            options = {
                tip = ''
            },
            placeholder = "请输入商户ID",
            rules = {{
                required = true,
                trigger = {"input", "blur"},
                message = "请输入商户ID"
            }}
        }}
    })
end

-- 创建订单
function plugin.create(pOrderInfo, pPluginOptions, pAccountInfo, pDeviceInfo)
    local orderInfo = json.decode(pOrderInfo)
    local options = json.decode(pPluginOptions)

    -- 判断是否有sid
    if options.sid == "" then
        return json.encode({
            err_code = 500,
            err_message = "请输入SID"
        })
    end

    if options.shop_id == "" then
        return json.encode({
            err_code = 500,
            err_message = "请输入商户ID"
        })
    end
    -- 构建请求URL
    local url = "https://sjtmgr.wxpapp.weixin.qq.com/sjt/linkqrcode/linkqrcode/create"
    url = url .. "?sid=" .. options.sid
    url = url .. "&v=0.69.8"

    log.debug(string.format("[插件] (%s) 创建订单 URL: %s", plugin.info.name, url))

    -- 构建请求体
    local body = {
        v = "0.69.8",
        shop_id = tonumber(options.shop_id),
        link_qr_code = {
            remark = orderInfo.order_id,
            payfee_type = "E_LINK_QRCODE_PAY_FEE_TYPE_FIX",
            image_description = {
                image_url_list = {}
            }
        },
        receipt_item = {{
            desc = orderInfo.order_id,
            price = tonumber(orderInfo.trade_amount),
            quota_type = "E_LINK_QRCODE_QUOTATYPE_NO_LIMIT"
        }},
        option_type = {},
        sid = options.sid
    }

    local result = http.post(url, {
        headers = {
            ["xweb_xhr"] = "1",
            ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090c11)XWEB/11581",
            ["Content-Type"] = "application/json",
            ["Referer"] = "https://servicewechat.com/wx9291fe7dadf5a574/169/page-frame.html",
            ["Accept-Language"] = "zh-CN,zh;q=0.9",
        },
        body = json.encode(body)
    })

    log.debug(string.format("[插件] (%s) 创建订单 GET %s", plugin.info.name, result.body))

    -- 判断返回状态
    if result.status_code ~= 200 then
        return json.encode({
            err_code = 500,
            err_message = string.format("请求失败,状态码:%d", result.status_code)
        })
    end

    -- 解析返回数据
    local response = json.decode(result.body)
    if not response then
        return json.encode({
            err_code = 500,
            err_message = "解析返回数据失败"
        })
    end

    -- 判断错误码
    if not response.errcode or response.errcode ~= 0 then
        return json.encode({
            err_code = 500,
            err_message = response.msg or "创建订单失败"
        })
    end

    -- 提取receipt_id
    local receipt_id = response.data.receipt_id
    if not receipt_id then
        return json.encode({
            err_code = 500,
            err_message = "未获取到receipt_id"
        })
    end

    local qrcode = response.data.qr_code_url
    if not qrcode then
        return json.encode({
            err_code = 500,
            err_message = "未获取到二维码"
        })
    end

    if qrcode == "" then
        return json.encode({
            err_code = 500,
            err_message = "二维码内容为空"
        })
    end

  


    return json.encode({
        type = "qrcode",
        qrcode = qrcode,
        url = "",
        content = "",
        out_trade_no = tostring(receipt_id),
        err_code = 200,
        err_message = ""
    })

end

-- 支付回调
function plugin.notify(request, orderInfo, params, pluginOptions)
    -- 判断请求方式
    return json.encode({
        error_code = 500,
        error_message = "暂不支持",
        response = ""
    })

end

-- 解析上报数据
function plugin.parseMsg(msg)
    -- 匹配到金额
    return json.encode({
        err_code = 500,
        err_message = "无需上报"
    })

end

-- 客户端心跳上报处理
function plugin.heartbeat(pChannelAccount, pHeartbeatRequest)
    local channelAccount = json.decode(pChannelAccount)
    -- 打印心跳数据
    log.info(string.format("(%s) 心跳数据: %s",channelAccount.plugin_name, pHeartbeatRequest))

    -- 解析心跳数据
    local heartbeatData = json.decode(pHeartbeatRequest)
    if heartbeatData == nil or heartbeatData.ext_data == nil or heartbeatData.ext_data == "" then
        return json.encode({
            err_code = 500,
            err_message = "心跳数据解析失败"
        })
    end

    -- 解析扩展数据
    local extData = json.decode(heartbeatData.ext_data)
    log.info(string.format("(%s) 心跳扩展数据 sid:%s shop_id:%s", channelAccount.plugin_name, extData.sid,
       extData.shop_id))

    -- 保存配置
    helper.channel_account_set_option(channelAccount.id, "sid", extData.sid)
    helper.channel_account_set_option(channelAccount.id, "shop_id", extData.shop_id)

    return json.encode({
        err_code = 200,
        err_message = "心跳正常"
    })

end

